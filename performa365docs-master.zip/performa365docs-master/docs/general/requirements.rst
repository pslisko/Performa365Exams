.. _requirements:

System Requirements For End Users
=================================

Performa 365 runs on any modern web browser on your PC, such as:

* Google Chrome (recommended version: most recent version or one below)
*	Mozilla Firefox (recommended version: most recent version or one below)
*	Microsoft Edge (recommended version: Microsoft EdgeHTML 16 or newer)
*	Microsoft Internet Explorer 11

Additional software or plug-ins may be needed to access specific learning content stored in your tenant.
