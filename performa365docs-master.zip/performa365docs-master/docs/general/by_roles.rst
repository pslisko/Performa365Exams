
.. _by_roles:

By roles
========



* :ref:`Tenant admin <tenant_administrator>`
* :ref:`Education process admin <education_process_administrator>`
* :ref:`Catalog admin <catalog_administrator>`
* :ref:`Enrollment admin <enrollment_administrator>`
* :ref:`Course owner <course_owner>`
* :ref:`Exam admin <exam_administrator>`
* :ref:`Exam creator <exam_creator>`
* :ref:`Instructor <instructor>`
* :ref:`Learner <learner>`
