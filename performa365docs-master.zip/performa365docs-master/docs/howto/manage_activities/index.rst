Manage Activities
==================

.. toctree::
  :maxdepth: 1
  :name: toc-manage-activities
  
  generic_video
  classroom_virtual
  exam
  html5
  survey
  office_mix
