.. _instructor:

Instructor
==========

This role is dynamically assigned to any user which is assigned to at least one classroom activitiy schedule as an instructor. 

..
Users in this role can perform following activities, only for their schedules:

* :ref:`Confirm Attendance <confirm_attendance>`
