.. _by_roles:

By User Roles
==============

.. toctree::
  :maxdepth: 1
  :name: toc-roles
  
  tenant_administrator
  education_process_administrator
  catalog_administrator
  enrollment_administrator
  course_owner
  test_administrator_and_test_creator
  instructor
  learner
