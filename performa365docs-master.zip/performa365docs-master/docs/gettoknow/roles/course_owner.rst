.. _course_owner:

Course Owner
=============

This role is dynamically assigned to any user which is assigned to at least one course as an owner. 

..
Users in this role can perform following activities, only for their „owned“ courses:

* :ref:`Edit a Course <edit_course>`
