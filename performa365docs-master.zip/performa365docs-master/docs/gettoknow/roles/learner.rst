.. _learner:

Learner
=====

Learner is the minimal role in the system. 

..

Users in this role can perform following actions:

* Browse the :ref:`Catalog<catalog>`
* View their :ref:`Learning plan<learning_plan>`
* :ref:`Take a Course<take_a_course>`
* View their *Profile page*
